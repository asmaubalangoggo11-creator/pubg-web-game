# BattleHub

An original battle-royale-inspired gaming dashboard built as a portfolio code sample.

## Technologies
- HTML5
- CSS3
- JavaScript

## Features
- Responsive design
- Fictional tactical map made with CSS
- Interactive mission tracker
- JavaScript modal
- No external libraries or paid services

## Run
Open `index.html` in any modern web browser.

## GitHub
Create a new public repository, upload `index.html` and `README.md`, then copy the repository URL into the application form.
